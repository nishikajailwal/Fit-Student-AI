import { GoogleGenAI } from "@google/genai";

export const calculateBMI = (weight: number, height: number) => {
  const heightInMeters = height / 100;
  return weight / (heightInMeters * heightInMeters);
};

export const calculateBMR = (weight: number, height: number, age: number, gender: string) => {
  if (gender === "male") {
    return 88.362 + (13.397 * weight) + (4.799 * height) - (5.677 * age);
  } else {
    return 447.593 + (9.247 * weight) + (3.098 * height) - (4.330 * age);
  }
};

export const getCalorieTarget = (bmr: number, goal: string) => {
  const maintenance = bmr * 1.375; // Moderate activity
  if (goal === "Muscle Gain") return maintenance + 300;
  if (goal === "Fat Loss") return maintenance - 500;
  return maintenance;
};

export const getProteinRequirement = (weight: number, goal: string) => {
  if (goal === "Muscle Gain") return weight * 1.8;
  if (goal === "Fat Loss") return weight * 2.0;
  return weight * 1.2;
};
