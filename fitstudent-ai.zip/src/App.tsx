import { useState, useEffect } from 'react';
import { 
  Dumbbell, 
  Utensils, 
  TrendingUp, 
  User, 
  MessageSquare, 
  LogOut, 
  ChevronRight, 
  Plus, 
  Calculator,
  Target,
  Wallet,
  Activity,
  Calendar,
  CheckCircle2
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import Markdown from 'react-markdown';
import { GoogleGenAI } from "@google/genai";
import { calculateBMI, calculateBMR, getCalorieTarget, getProteinRequirement } from './utils/fitness';

// Types
interface UserProfile {
  id?: number;
  name: string;
  email: string;
  age?: number;
  gender?: string;
  height?: number;
  weight?: number;
  goal?: string;
  budget?: string;
  diet_pref?: string;
  location?: string;
  experience?: string;
}

interface Plan {
  id: number;
  type: 'workout' | 'diet';
  content: string;
  created_at: string;
}

interface Progress {
  id: number;
  weight: number;
  date: string;
}

export default function App() {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [token, setToken] = useState<string | null>(localStorage.getItem('token'));
  const [view, setView] = useState<'dashboard' | 'profile' | 'plans' | 'chat' | 'progress'>('dashboard');
  const [plans, setPlans] = useState<Plan[]>([]);
  const [progress, setProgress] = useState<Progress[]>([]);
  const [loading, setLoading] = useState(false);
  const [backendStatus, setBackendStatus] = useState<'checking' | 'connected' | 'error'>('checking');
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [authForm, setAuthForm] = useState({ email: '', password: '', name: '' });

  useEffect(() => {
    checkBackend();
    if (token) {
      fetchProfile();
      fetchPlans();
      fetchProgress();
    }
  }, [token]);

  const checkBackend = async () => {
    try {
      const res = await fetch('/api/health');
      if (res.ok) setBackendStatus('connected');
      else setBackendStatus('error');
    } catch (e) {
      setBackendStatus('error');
    }
  };

  const fetchProfile = async () => {
    const res = await fetch('/api/user/profile', {
      headers: { Authorization: `Bearer ${token}` }
    });
    if (res.ok) setUser(await res.json());
  };

  const fetchPlans = async () => {
    const res = await fetch('/api/plans', {
      headers: { Authorization: `Bearer ${token}` }
    });
    if (res.ok) setPlans(await res.json());
  };

  const fetchProgress = async () => {
    const res = await fetch('/api/user/progress', {
      headers: { Authorization: `Bearer ${token}` }
    });
    if (res.ok) setProgress(await res.json());
  };

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    const endpoint = authMode === 'login' ? '/api/auth/login' : '/api/auth/register';
    const res = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(authForm)
    });
    const data = await res.json();
    if (data.token) {
      localStorage.setItem('token', data.token);
      setToken(data.token);
      setUser(data.user);
    } else {
      alert(data.error);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    setToken(null);
    setUser(null);
  };

  const generatePlan = async (type: 'workout' | 'diet') => {
    if (!user?.height || !user?.weight) {
      alert("Please complete your profile first");
      return;
    }

    setLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
      const model = "gemini-3.1-pro-preview";

      let prompt = "";
      if (type === "workout") {
        prompt = `Generate a personalized weekly workout plan for a student with the following profile:
          Age: ${user.age}, Gender: ${user.gender}, Height: ${user.height}cm, Weight: ${user.weight}kg,
          Goal: ${user.goal}, Location: ${user.location}, Experience: ${user.experience}.
          Include: Weekly split, exercises, sets, reps, and progressive overload tips. Format as Markdown.`;
      } else {
        prompt = `Generate a personalized budget-friendly diet plan for a student with the following profile:
          Age: ${user.age}, Gender: ${user.gender}, Height: ${user.height}cm, Weight: ${user.weight}kg,
          Goal: ${user.goal}, Budget: ${user.budget}, Diet Preference: ${user.diet_pref}.
          Focus on Indian vegetarian options like Paneer, Soya, Dal if applicable.
          Include: Breakfast, Lunch, Dinner, Snacks, and estimated daily macros (Calories, Protein, Carbs, Fats). Format as Markdown.`;
      }

      const result = await ai.models.generateContent({
        model,
        contents: prompt,
      });
      const content = result.text;

      // Save plan to backend
      const saveRes = await fetch('/api/plans/save', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ type, content })
      });

      if (saveRes.ok) {
        fetchPlans();
        setView('plans');
      }
    } catch (e) {
      console.error(e);
      alert("AI generation failed");
    } finally {
      setLoading(false);
    }
  };

  if (!token) {
    return (
      <div className="min-h-screen bg-zinc-950 text-white flex items-center justify-center p-4 font-sans">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-md bg-zinc-900 border border-zinc-800 p-8 rounded-3xl shadow-2xl"
        >
          <div className="flex justify-center mb-8">
            <div className="bg-emerald-500/10 p-4 rounded-2xl border border-emerald-500/20">
              <Activity className="w-10 h-10 text-emerald-500" />
            </div>
          </div>
          <h1 className="text-3xl font-bold text-center mb-2 tracking-tight">FitStudent AI</h1>
          <p className="text-zinc-400 text-center mb-8 text-sm">Your personalized AI fitness companion</p>
          
          <form onSubmit={handleAuth} className="space-y-4">
            {authMode === 'register' && (
              <div>
                <label className="block text-xs font-semibold text-zinc-500 uppercase tracking-wider mb-1">Name</label>
                <input 
                  type="text" 
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 focus:outline-none focus:border-emerald-500 transition-colors"
                  placeholder="John Doe"
                  value={authForm.name}
                  onChange={e => setAuthForm({...authForm, name: e.target.value})}
                  required
                />
              </div>
            )}
            <div>
              <label className="block text-xs font-semibold text-zinc-500 uppercase tracking-wider mb-1">Email</label>
              <input 
                type="email" 
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 focus:outline-none focus:border-emerald-500 transition-colors"
                placeholder="student@university.edu"
                value={authForm.email}
                onChange={e => setAuthForm({...authForm, email: e.target.value})}
                required
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-zinc-500 uppercase tracking-wider mb-1">Password</label>
              <input 
                type="password" 
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 focus:outline-none focus:border-emerald-500 transition-colors"
                placeholder="••••••••"
                value={authForm.password}
                onChange={e => setAuthForm({...authForm, password: e.target.value})}
                required
              />
            </div>
            <button className="w-full bg-emerald-500 hover:bg-emerald-600 text-black font-bold py-3 rounded-xl transition-all transform active:scale-95 mt-4">
              {authMode === 'login' ? 'Sign In' : 'Create Account'}
            </button>
          </form>
          
          <p className="text-center mt-6 text-sm text-zinc-500">
            {authMode === 'login' ? "Don't have an account? " : "Already have an account? "}
            <button 
              onClick={() => setAuthMode(authMode === 'login' ? 'register' : 'login')}
              className="text-emerald-500 font-semibold hover:underline"
            >
              {authMode === 'login' ? 'Sign Up' : 'Log In'}
            </button>
          </p>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col md:flex-row font-sans">
      {/* Sidebar */}
      <nav className="w-full md:w-64 bg-zinc-900 border-r border-zinc-800 p-6 flex flex-col gap-8">
        <div className="flex items-center gap-3 px-2">
          <Activity className="w-8 h-8 text-emerald-500" />
          <div className="flex flex-col">
            <span className="text-xl font-bold tracking-tight">FitStudent</span>
            <div className="flex items-center gap-1.5">
              <div className={`w-1.5 h-1.5 rounded-full ${backendStatus === 'connected' ? 'bg-emerald-500' : backendStatus === 'error' ? 'bg-red-500' : 'bg-zinc-500 animate-pulse'}`} />
              <span className="text-[10px] text-zinc-500 uppercase tracking-widest font-bold">
                {backendStatus === 'connected' ? 'Online' : backendStatus === 'error' ? 'Offline' : 'Connecting'}
              </span>
            </div>
          </div>
        </div>
        
        <div className="flex flex-col gap-2 flex-1">
          <NavItem active={view === 'dashboard'} icon={<TrendingUp size={20}/>} label="Dashboard" onClick={() => setView('dashboard')} />
          <NavItem active={view === 'profile'} icon={<User size={20}/>} label="My Profile" onClick={() => setView('profile')} />
          <NavItem active={view === 'plans'} icon={<CheckCircle2 size={20}/>} label="AI Plans" onClick={() => setView('plans')} />
          <NavItem active={view === 'progress'} icon={<Activity size={20}/>} label="Progress" onClick={() => setView('progress')} />
          <NavItem active={view === 'chat'} icon={<MessageSquare size={20}/>} label="AI Coach" onClick={() => setView('chat')} />
        </div>

        <button 
          onClick={handleLogout}
          className="flex items-center gap-3 px-4 py-3 text-zinc-500 hover:text-red-400 hover:bg-red-400/10 rounded-xl transition-all"
        >
          <LogOut size={20} />
          <span className="font-medium">Logout</span>
        </button>
      </nav>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto p-6 md:p-10">
        <AnimatePresence mode="wait">
          {view === 'dashboard' && <Dashboard user={user} plans={plans} progress={progress} setView={setView} generatePlan={generatePlan} loading={loading} />}
          {view === 'profile' && <ProfileForm user={user} token={token} onSave={fetchProfile} />}
          {view === 'plans' && <PlansList plans={plans} />}
          {view === 'progress' && <ProgressTracker progress={progress} token={token} onUpdate={fetchProgress} />}
          {view === 'chat' && <AICoach token={token} />}
        </AnimatePresence>
      </main>
    </div>
  );
}

function NavItem({ active, icon, label, onClick }: { active: boolean, icon: any, label: string, onClick: () => void }) {
  return (
    <button 
      onClick={onClick}
      className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
        active 
          ? 'bg-emerald-500 text-black font-bold shadow-lg shadow-emerald-500/20' 
          : 'text-zinc-500 hover:text-zinc-200 hover:bg-zinc-800'
      }`}
    >
      {icon}
      <span className="font-medium">{label}</span>
    </button>
  );
}

function Dashboard({ user, plans, progress, setView, generatePlan, loading }: any) {
  const bmi = user?.weight && user?.height ? calculateBMI(user.weight, user.height) : 0;
  const bmr = user?.weight && user?.height && user?.age && user?.gender ? calculateBMR(user.weight, user.height, user.age, user.gender) : 0;
  const calories = getCalorieTarget(bmr, user?.goal || 'Maintenance');
  const protein = getProteinRequirement(user?.weight || 0, user?.goal || 'Maintenance');

  const latestWorkout = plans.find((p: any) => p.type === 'workout');
  const latestDiet = plans.find((p: any) => p.type === 'diet');

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="max-w-6xl mx-auto space-y-8"
    >
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Welcome back, {user?.name}!</h2>
          <p className="text-zinc-500">Here's your fitness overview for today.</p>
        </div>
        <div className="flex gap-3">
          <button 
            onClick={() => generatePlan('workout')}
            disabled={loading}
            className="bg-zinc-800 hover:bg-zinc-700 text-white px-6 py-3 rounded-xl font-semibold flex items-center gap-2 transition-all disabled:opacity-50"
          >
            <Dumbbell size={18} />
            {loading ? 'Generating...' : 'New Workout'}
          </button>
          <button 
            onClick={() => generatePlan('diet')}
            disabled={loading}
            className="bg-emerald-500 hover:bg-emerald-600 text-black px-6 py-3 rounded-xl font-bold flex items-center gap-2 transition-all disabled:opacity-50"
          >
            <Utensils size={18} />
            {loading ? 'Generating...' : 'New Diet'}
          </button>
        </div>
      </header>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="BMI Score" value={bmi.toFixed(1)} icon={<Calculator className="text-blue-400" />} subtext={bmi < 18.5 ? 'Underweight' : bmi < 25 ? 'Healthy' : 'Overweight'} />
        <StatCard label="Daily Calories" value={Math.round(calories).toString()} icon={<Target className="text-orange-400" />} subtext="Target Intake" />
        <StatCard label="Daily Protein" value={`${Math.round(protein)}g`} icon={<Activity className="text-emerald-400" />} subtext="Muscle Support" />
        <StatCard label="Budget Level" value={user?.budget || 'N/A'} icon={<Wallet className="text-purple-400" />} subtext="Student Optimized" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Progress Chart */}
        <div className="lg:col-span-2 bg-zinc-900 border border-zinc-800 p-6 rounded-3xl">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-bold">Weight Progress</h3>
            <button onClick={() => setView('progress')} className="text-emerald-500 text-sm font-semibold hover:underline">View Details</button>
          </div>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={progress}>
                <CartesianGrid strokeDasharray="3 3" stroke="#27272a" />
                <XAxis dataKey="date" stroke="#71717a" fontSize={12} />
                <YAxis stroke="#71717a" fontSize={12} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#18181b', border: '1px solid #27272a', borderRadius: '12px' }}
                  itemStyle={{ color: '#10b981' }}
                />
                <Line type="monotone" dataKey="weight" stroke="#10b981" strokeWidth={3} dot={{ fill: '#10b981' }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Quick Access Plans */}
        <div className="space-y-4">
          <h3 className="text-xl font-bold">Latest Plans</h3>
          {latestWorkout ? (
            <div className="bg-zinc-900 border border-zinc-800 p-5 rounded-2xl hover:border-emerald-500/50 transition-all cursor-pointer" onClick={() => setView('plans')}>
              <div className="flex items-center gap-3 mb-3">
                <div className="bg-emerald-500/10 p-2 rounded-lg"><Dumbbell className="text-emerald-500" size={20} /></div>
                <span className="font-bold">Workout Plan</span>
              </div>
              <p className="text-zinc-500 text-sm line-clamp-3">Your personalized {user?.location} routine for {user?.goal}.</p>
            </div>
          ) : (
            <div className="bg-zinc-900/50 border border-dashed border-zinc-800 p-8 rounded-2xl text-center">
              <p className="text-zinc-500 text-sm mb-4">No workout plan yet.</p>
              <button onClick={() => generatePlan('workout')} className="text-emerald-500 text-sm font-bold">Generate Now</button>
            </div>
          )}

          {latestDiet ? (
            <div className="bg-zinc-900 border border-zinc-800 p-5 rounded-2xl hover:border-emerald-500/50 transition-all cursor-pointer" onClick={() => setView('plans')}>
              <div className="flex items-center gap-3 mb-3">
                <div className="bg-emerald-500/10 p-2 rounded-lg"><Utensils className="text-emerald-500" size={20} /></div>
                <span className="font-bold">Diet Plan</span>
              </div>
              <p className="text-zinc-500 text-sm line-clamp-3">Budget-friendly {user?.diet_pref} meals optimized for you.</p>
            </div>
          ) : (
            <div className="bg-zinc-900/50 border border-dashed border-zinc-800 p-8 rounded-2xl text-center">
              <p className="text-zinc-500 text-sm mb-4">No diet plan yet.</p>
              <button onClick={() => generatePlan('diet')} className="text-emerald-500 text-sm font-bold">Generate Now</button>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}

function StatCard({ label, value, icon, subtext }: any) {
  return (
    <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-3xl">
      <div className="flex items-center justify-between mb-4">
        <span className="text-zinc-500 text-sm font-semibold uppercase tracking-wider">{label}</span>
        {icon}
      </div>
      <div className="text-3xl font-bold mb-1">{value}</div>
      <div className="text-zinc-500 text-xs font-medium">{subtext}</div>
    </div>
  );
}

function ProfileForm({ user, token, onSave }: any) {
  const defaults = {
    age: 20,
    gender: 'Male',
    height: 175,
    weight: 70,
    goal: 'Muscle Gain',
    budget: 'Medium',
    diet_pref: 'Vegetarian',
    location: 'Gym',
    experience: 'Beginner'
  };

  const [formData, setFormData] = useState(defaults);

  useEffect(() => {
    if (user) {
      const merged = { ...defaults };
      Object.keys(defaults).forEach((key) => {
        const val = (user as any)[key];
        if (val !== null && val !== undefined) {
          (merged as any)[key] = val;
        }
      });
      setFormData(merged);
    }
  }, [user]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Ensure numeric values are numbers
    const payload = {
      ...formData,
      age: parseInt(formData.age as any) || 0,
      height: parseFloat(formData.height as any) || 0,
      weight: parseFloat(formData.weight as any) || 0
    };

    const res = await fetch('/api/user/profile', {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify(payload)
    });
    if (res.ok) {
      alert('Profile updated!');
      onSave();
    } else {
      const data = await res.json();
      alert(data.error || 'Failed to update profile');
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="max-w-2xl mx-auto bg-zinc-900 border border-zinc-800 p-8 rounded-3xl"
    >
      <h2 className="text-2xl font-bold mb-6">Complete Your Profile</h2>
      <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Input label="Age" type="number" value={formData.age} onChange={(v: any) => setFormData({...formData, age: parseInt(v)})} />
        <Select label="Gender" value={formData.gender} options={['Male', 'Female', 'Other']} onChange={(v: any) => setFormData({...formData, gender: v})} />
        <Input label="Height (cm)" type="number" value={formData.height} onChange={(v: any) => setFormData({...formData, height: parseFloat(v)})} />
        <Input label="Weight (kg)" type="number" value={formData.weight} onChange={(v: any) => setFormData({...formData, weight: parseFloat(v)})} />
        <Select label="Goal" value={formData.goal} options={['Muscle Gain', 'Fat Loss', 'Maintenance']} onChange={(v: any) => setFormData({...formData, goal: v})} />
        <Select label="Budget" value={formData.budget} options={['Low', 'Medium', 'High']} onChange={(v: any) => setFormData({...formData, budget: v})} />
        <Select label="Diet Preference" value={formData.diet_pref} options={['Vegetarian', 'Eggetarian', 'Non-veg']} onChange={(v: any) => setFormData({...formData, diet_pref: v})} />
        <Select label="Workout Location" value={formData.location} options={['Home', 'Gym']} onChange={(v: any) => setFormData({...formData, location: v})} />
        <Select label="Experience" value={formData.experience} options={['Beginner', 'Intermediate', 'Advanced']} onChange={(v: any) => setFormData({...formData, experience: v})} />
        
        <div className="md:col-span-2 mt-4">
          <button className="w-full bg-emerald-500 hover:bg-emerald-600 text-black font-bold py-4 rounded-xl transition-all">
            Save Profile & Analyze
          </button>
        </div>
      </form>
    </motion.div>
  );
}

function Input({ label, type, value, onChange }: any) {
  return (
    <div>
      <label className="block text-xs font-semibold text-zinc-500 uppercase tracking-wider mb-2">{label}</label>
      <input 
        type={type} 
        value={value ?? ''} 
        onChange={e => onChange(e.target.value)}
        className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 focus:outline-none focus:border-emerald-500 transition-colors"
      />
    </div>
  );
}

function Select({ label, value, options, onChange }: any) {
  return (
    <div>
      <label className="block text-xs font-semibold text-zinc-500 uppercase tracking-wider mb-2">{label}</label>
      <select 
        value={value ?? ''} 
        onChange={e => onChange(e.target.value)}
        className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 focus:outline-none focus:border-emerald-500 transition-colors appearance-none"
      >
        {options.map((opt: string) => <option key={opt} value={opt}>{opt}</option>)}
      </select>
    </div>
  );
}

function PlansList({ plans }: { plans: Plan[] }) {
  const [selectedPlan, setSelectedPlan] = useState<Plan | null>(plans[0] || null);

  return (
    <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-4 gap-8">
      <div className="lg:col-span-1 space-y-4">
        <h3 className="text-xl font-bold mb-4">Your Plans</h3>
        {plans.map(plan => (
          <button 
            key={plan.id}
            onClick={() => setSelectedPlan(plan)}
            className={`w-full text-left p-4 rounded-2xl border transition-all ${
              selectedPlan?.id === plan.id 
                ? 'bg-emerald-500/10 border-emerald-500 text-emerald-500' 
                : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:border-zinc-700'
            }`}
          >
            <div className="flex items-center gap-2 mb-1">
              {plan.type === 'workout' ? <Dumbbell size={16} /> : <Utensils size={16} />}
              <span className="font-bold capitalize">{plan.type} Plan</span>
            </div>
            <div className="text-xs opacity-60">{new Date(plan.created_at).toLocaleDateString()}</div>
          </button>
        ))}
      </div>
      <div className="lg:col-span-3 bg-zinc-900 border border-zinc-800 p-8 rounded-3xl overflow-y-auto max-h-[80vh]">
        {selectedPlan ? (
          <div className="prose prose-invert max-w-none">
            <Markdown>{selectedPlan.content}</Markdown>
          </div>
        ) : (
          <div className="h-full flex flex-col items-center justify-center text-zinc-500">
            <Activity size={48} className="mb-4 opacity-20" />
            <p>Select a plan to view details</p>
          </div>
        )}
      </div>
    </div>
  );
}

function ProgressTracker({ progress, token, onUpdate }: any) {
  const [weight, setWeight] = useState('');

  const addProgress = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch('/api/user/progress', {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify({ weight: parseFloat(weight) })
    });
    if (res.ok) {
      setWeight('');
      onUpdate();
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="bg-zinc-900 border border-zinc-800 p-8 rounded-3xl">
        <h3 className="text-xl font-bold mb-6">Log Today's Weight</h3>
        <form onSubmit={addProgress} className="flex gap-4">
          <input 
            type="number" 
            step="0.1"
            placeholder="Weight (kg)"
            value={weight}
            onChange={e => setWeight(e.target.value)}
            className="flex-1 bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 focus:outline-none focus:border-emerald-500"
            required
          />
          <button className="bg-emerald-500 hover:bg-emerald-600 text-black font-bold px-8 rounded-xl transition-all">
            Log Weight
          </button>
        </form>
      </div>

      <div className="bg-zinc-900 border border-zinc-800 rounded-3xl overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-zinc-800/50">
            <tr>
              <th className="px-6 py-4 text-xs font-semibold text-zinc-500 uppercase tracking-wider">Date</th>
              <th className="px-6 py-4 text-xs font-semibold text-zinc-500 uppercase tracking-wider">Weight</th>
              <th className="px-6 py-4 text-xs font-semibold text-zinc-500 uppercase tracking-wider">Change</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-zinc-800">
            {progress.slice().reverse().map((entry: any, i: number) => {
              const prev = progress[progress.length - 1 - i - 1];
              const diff = prev ? entry.weight - prev.weight : 0;
              return (
                <tr key={entry.id}>
                  <td className="px-6 py-4 text-sm">{new Date(entry.date).toLocaleDateString()}</td>
                  <td className="px-6 py-4 font-bold">{entry.weight} kg</td>
                  <td className={`px-6 py-4 text-sm ${diff > 0 ? 'text-red-400' : diff < 0 ? 'text-emerald-400' : 'text-zinc-500'}`}>
                    {diff > 0 ? '+' : ''}{diff.toFixed(1)} kg
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function AICoach({ token }: { token: string | null }) {
  const [messages, setMessages] = useState<{role: 'user' | 'ai', text: string}[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || loading) return;

    const userMsg = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
      const chat = ai.chats.create({
        model: "gemini-3.1-pro-preview",
        config: {
          systemInstruction: `You are a professional fitness and nutrition coach for students. 
          Provide concise, encouraging, and scientifically accurate advice.`,
        }
      });

      const result = await chat.sendMessage({ message: userMsg });
      setMessages(prev => [...prev, { role: 'ai', text: result.text }]);
    } catch (e) {
      console.error(e);
      setMessages(prev => [...prev, { role: 'ai', text: "Sorry, I'm having trouble connecting right now." }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto h-[80vh] flex flex-col bg-zinc-900 border border-zinc-800 rounded-3xl overflow-hidden">
      <div className="p-6 border-bottom border-zinc-800 bg-zinc-800/30 flex items-center gap-3">
        <div className="bg-emerald-500/20 p-2 rounded-lg"><MessageSquare className="text-emerald-500" size={20} /></div>
        <div>
          <h3 className="font-bold">AI Fitness Coach</h3>
          <p className="text-xs text-zinc-500">Ask me anything about your workout or diet</p>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-6 space-y-4">
        {messages.length === 0 && (
          <div className="h-full flex flex-col items-center justify-center text-zinc-500 text-center px-10">
            <Activity size={48} className="mb-4 opacity-20" />
            <p>Hi! I'm your AI Coach. Need help with exercise form, budget meal prep, or staying motivated? Just ask!</p>
          </div>
        )}
        {messages.map((msg, i) => (
          <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[80%] p-4 rounded-2xl ${
              msg.role === 'user' 
                ? 'bg-emerald-500 text-black font-medium' 
                : 'bg-zinc-800 text-zinc-200'
            }`}>
              <Markdown>{msg.text}</Markdown>
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="bg-zinc-800 p-4 rounded-2xl animate-pulse text-zinc-500">Coach is thinking...</div>
          </div>
        )}
      </div>

      <form onSubmit={sendMessage} className="p-4 bg-zinc-950 border-t border-zinc-800 flex gap-2">
        <input 
          type="text" 
          value={input}
          onChange={e => setInput(e.target.value)}
          placeholder="Type your question..."
          className="flex-1 bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 focus:outline-none focus:border-emerald-500"
        />
        <button className="bg-emerald-500 hover:bg-emerald-600 text-black p-3 rounded-xl transition-all">
          <ChevronRight />
        </button>
      </form>
    </div>
  );
}
